import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  /*styleUrls: ['./register.component.css']*/
})
export class RegisterComponent implements OnInit {

  username:string;
password:string;
repassword:string;
email:string;
autherized: boolean;
 errorMessage: string;
 myFormGroup : FormGroup;


  constructor(public router:Router) { }
  checkLogin(txtLogin : HTMLInputElement, txtPass : HTMLInputElement){
    this.router.navigate(['/login']);
  }
  ngOnInit() {
  }

}
