export class User{
    id: number;
    name : string;
    password : string;
    email: string;
    firstname:string;
    lastname:string;
    dob:number;
    enabled:boolean;

    constructor(name:string, password:string, firstname:string,lastname:string, dob:number,email:string,enabled:boolean){
        this.name = name;
        this.password = password;
        this.email = email;
        this.firstname=firstname;
        this.lastname=lastname;
        this.dob=dob;
        this.enabled=enabled;
    }
}