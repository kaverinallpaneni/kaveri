import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserLoggedInGaurdService implements CanActivate {

  constructor(public auth : AuthenticationService, public router : Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

  
    if(this.auth.isUserLoggedIn())
        return true;
    else{
    
      this.router.navigate(['/mymedia']);
      return false;
    }    
        
}

}
