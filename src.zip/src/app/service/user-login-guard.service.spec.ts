import { TestBed } from '@angular/core/testing';

import { UserLoggedInGaurdService } from './user-login-guard.service';

describe('UserLoggedInGaurdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserLoggedInGaurdService = TestBed.get(UserLoggedInGaurdService);
    expect(service).toBeTruthy();
  });
});
