import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/app/model/user.model';


const API_URL = "http://localhost:9090/user-service/users"; // url of server

@Injectable({
  providedIn: 'root'
})
// service to interact with REST Server for Product entity
export class UserDataService {

  // recieve the Http Service injected
  constructor(public http : HttpClient) { 

  }

  // gets product list from server and returns back
  getAllUsers(){
    // send request to server to get all products
    // this.http.post(API_URL);
    // will send a request to API_URL with http verb GET(retrieval)
    // method will wait for data to receive
    // return data back to component
    return this.http.get(API_URL);
  }

  // method to send new object(product) to server
  addNewUser(user: User){
    // POST http verb
    return this.http.post(API_URL, user);
  }

  // methid to get single record of given id
  getOneUser(id:number){
    // GET http verb
    return this.http.get(API_URL + "/" + id);

  }

  // method to send updated object(product) to server
  updateUser(id:number, user : User){
    // PUT http verb
    return this.http.put(API_URL + "/" + id, user);
  }

  // method to delete single record of given id
  deleteUser(id:number){
    // DELETE http verb
    return this.http.delete(API_URL + "/" + id);

  }

}
