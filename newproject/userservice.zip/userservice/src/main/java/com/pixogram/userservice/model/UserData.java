package com.pixogram.userservice.model;

import java.util.List;

import com.pixogram.userservice.entity.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserData {
	
	List<User> data;
}
