import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-accountupdate',
  templateUrl: './accountupdate.component.html',
 /* styleUrls: ['./accountupdate.component.css']*/
})
export class AccountupdateComponent implements OnInit {
 

  constructor() { }
  
  ngOnInit() {
  }
}
