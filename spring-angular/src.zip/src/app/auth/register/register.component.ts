import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { UserRegistrationService } from 'src/app/service/user registration/user-registration.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  /*styleUrls: ['./register.component.css']*/
})
export class RegisterComponent implements OnInit {


  username : string;
  password:string;
  email : string;
  repassword : string;
  sucesstxt: string;
  errtext: string;
  myFormGroup : FormGroup;
  repass:string;
  pass: string;
  user: string;
 

  constructor(public router:Router,formBuilder: FormBuilder,public details:UserRegistrationService) { 
    this.myFormGroup=formBuilder.group({
     
      "username":new FormControl(""),
          "password": new FormControl(""),
          "repassword":new FormControl(""),
          "email":new FormControl("")
     });
  }
  
  register(){
    this.username= this.myFormGroup.controls['username'].value;
      this.password=this.myFormGroup.controls['password'].value;
      this.repassword=this.myFormGroup.controls['repassword'].value;
      this.email=this.myFormGroup.controls['email'].value;
      let details=new UserRegistrationDetails(this.user,this.pass,this.repass,this.email);

      this.details.addNewUser(details).subscribe((response)=> console.log(response));
      
      
      console.log("username :" +this.user+"\n" + "email :" +this.email+"\n"+ "password :"+this.pass+"\n"+ "repassword :"+this.repass+"\n");
      if (this.pass === this.repass){    
      this.sucesstxt = "registerd successfully";
           this.errtext="";
            
      
         }
         else{
          this.errtext = "Password not matched";
         this.sucesstxt="";
         }
    
       
      }
    
    
     
    
  ngOnInit() {
  }

}
