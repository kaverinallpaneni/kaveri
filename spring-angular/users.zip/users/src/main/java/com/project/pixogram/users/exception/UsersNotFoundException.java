package com.project.pixogram.users.exception;

public class UsersNotFoundException extends RuntimeException{
	public UsersNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
