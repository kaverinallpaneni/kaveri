package com.project.pixogram.users.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name="authorities")
@Getter
@Setter
@AllArgsConstructor
public class Authorities implements Serializable {


	@Id
	@Column(name="username", length=100)
	private String username;
	
	@Id
	@Column(name="authority", length=100)
	private String role;
}
