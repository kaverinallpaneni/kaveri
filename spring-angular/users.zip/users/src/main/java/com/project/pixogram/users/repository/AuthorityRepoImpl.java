package com.project.pixogram.users.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.project.pixogram.users.entity.Authorities;

@Repository
@Transactional
public class AuthorityRepoImpl implements AuthorityRepository {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void save(Authorities authorities) {
		// TODO Auto-generated method stub
		this.em.persist(authorities);
	}

}
