import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { SearchedUserlList } from 'src/app/model/searcheduserlist.model';
import { SearchedUser } from 'src/app/model/searcheduser.model';

@Component({
  selector: 'app-search',
 templateUrl: './search.component.html',
  //styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  userList : Array<SearchedUser>;

  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  constructor(public auth:AuthenticationService,formBuilder : FormBuilder,private userService: UserserviceService) { 
    this.myFormGroup = formBuilder.group(
      {
        "keyword" : new FormControl(),
      }
    );

   }
   search(){
    this.searchtext = this.myFormGroup.controls['keyword'].value;
    this.userService.getSearchedUsers(this.searchtext).subscribe(
     (response : SearchedUserlList) => {
       this.userList = response.userList;
       this.userList = this.userList.map(user =>{
         user.profileUrl = "http://localhost:8765/user-service/"+user.profileUrl;
         return user;
       });
       
     }
   );
  }

  
 
    
}


  

