import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadmedia',
  templateUrl: './uploadmedia.component.html',
  //styleUrls: ['./uploadmedia.component.css']
})
export class UploadmediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
