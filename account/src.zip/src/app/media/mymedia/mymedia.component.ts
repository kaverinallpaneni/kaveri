import { Component, OnInit } from '@angular/core';
import { MediaserviceService } from 'src/app/services/mediaservice.service';
import { Router } from '@angular/router';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { MediaModel } from 'src/app/model/mediamodel';
import { MediaListModel } from 'src/app/model/medialistmodel';


@Component({
  selector: 'app-mymedia',
  templateUrl: './mymedia.component.html',
  //styleUrls: ['./mymedia.component.css']
})
export class MymediaComponent implements OnInit {
  medialist : Array<MediaModel>;
  constructor(public mediaService : MediaserviceService , public router  : Router , public userService : UserserviceService) { }
  getDetails(id : number){
    console.log(id);
    this.router.navigate(['/media-details/'+id])
   }
  
 ngOnInit() {
  this.mediaService.getAllMedia().subscribe((responce : MediaListModel)=>{
    this.medialist=responce.filelist.map(media => {
      media.url = "http://localhost:8765/media-service/" + media.url;
      return media;
    
    });
    console.log(this.medialist)
  });
  
}
    
  }
  
  