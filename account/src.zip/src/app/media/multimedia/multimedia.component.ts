import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MediaModel } from 'src/app/model/mediamodel';

@Component({
  selector: 'app-multimedia',
  templateUrl: './multimedia.component.html',
  //styleUrls: ['./multimedia.component.css']
})
export class MultimediaComponent implements OnInit {
  title: string;
  description: string;
  tags : string;
  myFormGroup : FormGroup;
 selectedFile:FileList;
 date:Date;
 currentFileUpload: File;
  file: string;
  url: any;
  router: any;
  mediaService: any;
  userId: number;
  
constructor(formBuilder : FormBuilder) {
 this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
    
     });
   }

   OnImageLoad(event){
    this.selectedFile=event.target.files;
    this.currentFileUpload=this.selectedFile.item(0);
      }
  
  
  multimedia(){
      this.title= this.myFormGroup.controls['Title'].value;
      this.description=this.myFormGroup.controls['Description'].value;
      this.tags=this.myFormGroup.controls['Tags'].value;
      this.date = new Date();
      let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
      if (this.currentFileUpload.type == 'image/png') {
        this.file = `${this.title}${dateString}.png`;
      }
      if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
        this.file = `${this.title}${dateString}.jpeg`;
      }
      console.log("Title : "+this.title+"\n"+"Description : "+this.description+"\n"+"Tags : "+this.tags);
    
      let uploadfile=new MediaModel(this.description,this.file,this.title,this.tags)
      this.mediaService.pushFileToStorage(this.currentFileUpload,this.title,this.description,this.file,this.tags,this.currentFileUpload.type).subscribe(
       (response)=>{this.router.navigate(['/mymedia/'])});
      
     
    
      }
      message(){
        alert("you have uploaded the media files you have navigated to mediadetails")
      }
    
      
  

  ngOnInit() {
  }

}
