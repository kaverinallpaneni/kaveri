export class Follow {
   userId : number;
   followerId :number;
   constructor(userId,followerId){
         
    this.userId= userId ;
    this.followerId = followerId;
   
}
}
