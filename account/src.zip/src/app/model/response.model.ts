export class ResponseData{
    message : String;
    timeStamp : number;
    userId : number;
    profilepic:string;
    
}