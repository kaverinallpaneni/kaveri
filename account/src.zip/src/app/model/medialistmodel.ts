import { MediaModel } from './mediamodel';

export class MediaListModel {

	filelist : Array<MediaModel>;

}