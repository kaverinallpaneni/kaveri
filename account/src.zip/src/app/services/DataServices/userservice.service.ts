import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { Userid } from 'src/app/model/userid.model';
import { Follow } from 'src/app/model/Follow.model';
const API_URL = "http://localhost:8765/user-service/users";
const REG_URL = "http://localhost:8765/user-service/register";
const UseridURL = "http://localhost:8765/user-service/custom";
const UsernamesURL = "http://localhost:8765/user-service/usernames";
const SEARCH_URL = "http://localhost:8765/misc-plumbing";
const MISC_URL = "http://localhost:8765/misc-plumbing";
const FOLLOW_URL = "http://localhost:8765/follow-service"

@Injectable({
  providedIn: 'root'
})


export class UserserviceService {
  user : Userid;
  constructor(public http : HttpClient) {}
  doFollow(follow : Follow):any{
    return this.http.post(FOLLOW_URL+"/follow",follow);
   }
   doUnFollow(other : number):any{
     console.log(other);
     return this.http.delete(FOLLOW_URL+"/unfollow/mine/"+sessionStorage.getItem("userid")+"/other/"+other);
   }
    getSearchedUsers(searchText : string){
      return this.http.get(MISC_URL + "/searched-users/" + searchText + "/myid/" + sessionStorage.getItem("userid"));
    }
   getAllUsernames():any{
     return this.http.get(UsernamesURL);
   }
 
   getId():any {
     
     let name = sessionStorage.getItem("username");
     return this.http.get(UseridURL+"/"+name);
    
   }


  

  getAllUsers():any{
    return this.http.get(API_URL);
  }

  getUser(id:number):any{
    return this.http.get(API_URL+"/"+id);
  }

  addUser(user:UserRegistrationDetails):any{
    return this.http.post(REG_URL,user);
  }

  delete(id:number){
    this.http.delete(API_URL+"/"+id);
  }

  update(id:number,user:UserRegistrationDetails):any{
    return this.http.put(API_URL+"/"+id,user);
  }
}
