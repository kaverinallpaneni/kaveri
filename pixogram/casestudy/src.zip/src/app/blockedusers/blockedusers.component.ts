import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockedusers',
  templateUrl: './blockedusers.component.html',
  /*styleUrls: ['./blockedusers.component.css']*/
})
export class BlockedusersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
