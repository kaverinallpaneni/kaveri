package com.project.pixogram.plumbingmicroservice.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.project.pixogram.plumbingmicroservice.feignproxy.MediaServiceProxy;
import com.project.pixogram.plumbingmicroservice.model.Media;




public class MediaController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@Autowired
	private MediaServiceProxy movieProxy;
	
	
	
	//private final String RATING_URL = "http://localhost:6060/rating-service/ratings";
	private final String MEDIA_URL = "http://localhost:9090/movie-service/movies"; 
	// Controller method recieves userId and return list of movies viewed by that user + movie details + rating
	// ENDPOINT : /catalog/{userId}
	@GetMapping("/catalog/{userId}")
	public ResponseEntity<Media> getCatalogs(@PathVariable Integer userId){
		
		// 1. sent a request to rating service to fetch the list of movies
		//RatingData ratingData = this.restTemplate.getForObject(RATING_URL + "/" + userId, RatingData.class);
		
		// 2. sent request to movie service to fetch movie details
		// need to loop through movielist(ratingData)
		
		List<Media> catalogs = new ArrayList<Media>();
		
		for(RatingModel ratingModel : ratingData.getRatingModels()) {
			Integer movieId =  ratingModel.getMediaId();
			Media media = this.restTemplate.getForObject(MEDIA_URL + "/" + mediaId, Media.class);
			
			// club both info in Catalog
			Media media= new Media(mediaId, 
										 
										  media.getTitle(), 
										  ratingModel.getRating());
			
			// add to collection of catalogs
			media.add(media);		
		}
		
		Media media = new Media();
		media.setUserId(userId);
		mediaData.setMedia(medias);
		
		ResponseEntity<MediaData> response = 
				new ResponseEntity<MediaData>(MediaData, HttpStatus.OK);
		
		return response;
	}
	
	@GetMapping("/media-feign/{userId}")
	public ResponseEntity<MediaData> getMediasFeign(@PathVariable Integer userId){
		
		// 1. sent a request to rating service to fetch the list of movies
		// RatingData ratingData = this.restTemplate.getForObject(RATING_URL + "/" + userId, RatingData.class);
		ResponseEntity<RatingData> rResponse = this.ratingProxy.getRatings(userId);
		RatingData ratingData =  rResponse.getBody();
		
		// 2. sent request to movie service to fetch movie details
		// need to loop through movielist(ratingData)
		
		List<Media> s = new ArrayList<Media>();
		
		for(RatingModel ratingModel : ratingData.getRatingModels()) {
			Integer movieId =  ratingModel.getMovieId();
			// Movie movie = this.restTemplate.getForObject(MOVIE_URL + "/" + movieId, Movie.class);
			ResponseEntity<Media> mResponse = this.movieProxy.mediaDetail(mediaId);
			Media media = mResponse.getBody();
			
			// club both info in Catalog
			Media media = new Media(movieId, 
										  media.getTitle(), 
										 
										 
			// add to collection of catalogs
			medias.add(media);		
		}
		
		MediaData mediaData = new MediaData();
		mediaData.setUserId(userId);
		mediaData.setMedias(medias);
		
		ResponseEntity<MediaData> response = 
				new ResponseEntity<MediaData>(mediaData, HttpStatus.OK);
		
		return response;
	}
	
}

