package com.project.pixogram.plumbingmicroservice.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Media {

	private Integer id;
	private String userid;
	private String title;
	private String description;
	
}
