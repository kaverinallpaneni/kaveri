package com.project.pixogram.plumbingmicroservice.feignproxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.pixogram.plumbingmicroservice.model.Media;

public interface MediaServiceProxy {
	
	@FeignClient(name = "media-service", path = "http://localhost:6064") // context-path
	//@FeignClient(name = "movie-service") // path is managed by server
	//@FeignClient(name = "api-gateway") // for passing all request through API Gateway
	// configure the Ribbon to load balance
	@RibbonClient(name = "media-service") // will activate load balancing on movie-service
	public interface MovieServiceProxy {
		// @GetMapping("/movies/{movieId}")
		@GetMapping("media-service/medias/{mediaId}")
		public ResponseEntity<Media> mediaDetail(@PathVariable Integer mediaId);
	
	}
}

