package com.cts.training.media.exception;

public class MediaNotFoundException extends RuntimeException {
	
public MediaNotFoundException(String message) {
		
		super(message);
	}
}
