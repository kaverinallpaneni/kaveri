package com.cts.training.media.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.training.media.entity.Media;
import com.cts.training.media.exception.MediaErrorResponse;
import com.cts.training.media.exception.MediaNotFoundException;
import com.cts.training.media.service.IMediaService;

@Controller
public class MediaController {

	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IMediaService mediaService;
	@GetMapping("/medias") 
	public ResponseEntity<List<Media>> exposeAll() {
		
		List<Media> medias = this.mediaService.findAllMedias();
		// if(products.size() == 0)
		if(medias== null)
			throw new MediaNotFoundException("Not able to fetch records!!!");
		ResponseEntity<List<Media>> response = 
								new ResponseEntity<List<Media>>(medias, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/medias/{mediaId}") // GET HTTP VERB
	public ResponseEntity<Media> getById(@PathVariable Integer mediaId) {
		
		Media media = this.mediaService.findMediaById(mediaId);
		if(media== null)
			throw new MediaNotFoundException("Media with id-" + mediaId + " not Found");
		
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/products", method = RequestMethod.POST)
	@PostMapping("/medias") // POST HTTP VERB
	public ResponseEntity<Media> save(@RequestBody Media media) {
		if(!this.mediaService.addMedia(media))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/medias")
	public ResponseEntity<Media> saveUpdate(@RequestBody Media media) {
		if(!this.mediaService.updateMedia(media))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/medias/{mediaId}")
	public ResponseEntity<Media> delete(@PathVariable Integer mediaId) {
		
		Media media = this.mediaService.findMediaById(mediaId);
		if(media== null)
			throw new MediaNotFoundException("Media with id-" + mediaId + " not Found");
		
		// send productId to DAO via SERVICE
		this.mediaService.deleteMedia(mediaId);
		
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	
	// for exception handling
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> mediaNotFoundHandler(MediaNotFoundException ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> mediaOperationErrorHAndler(Exception ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	

}
