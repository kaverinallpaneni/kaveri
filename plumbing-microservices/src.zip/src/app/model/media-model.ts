export class MediaDetails{
    userid:number;
    title:string;
    description:string;
    tags:string;
    url:string;
    

    constructor(title:string,description:string,tags:string,url:string){
this.title=title;
this.description=description;
this.tags=tags;
this.url=url;



    }
}