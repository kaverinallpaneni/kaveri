export class ResponseData{
    message : String;
    timestamp : number;
    userId : number;
    profilePic:string;
    
}