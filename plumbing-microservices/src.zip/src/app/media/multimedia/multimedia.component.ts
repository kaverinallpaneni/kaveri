import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-multimedia',
  templateUrl: './multimedia.component.html',
  //styleUrls: ['./multimedia.component.css']
})
export class MultimediaComponent implements OnInit {
  title: String;
  description: String;
  tags : String;
  myFormGroup : FormGroup;
 

  constructor(formBuilder : FormBuilder) {
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
   }
  multimedia(){
      this.title= this.myFormGroup.controls['Title'].value;
      this.description=this.myFormGroup.controls['Description'].value;
      this.tags=this.myFormGroup.controls['Tags'].value;
      
  }

  ngOnInit() {
  }

}
