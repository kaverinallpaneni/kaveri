import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { MediaserviceService } from 'src/app/services/mediaservice.service';
import { Router } from '@angular/router';
import { MediaDetails } from 'src/app/model/media-model';


@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  //styleUrls: ['./singlemedia.component.css']
})
export class SinglemediaComponent implements OnInit {

  myFormGroup: FormGroup;
  description: string;
  title: string;
  tags: string;
  date: Date;
  selectedFile: any;
  file: string;

  
 
  constructor(formBuilder : FormBuilder,public mediaservice:MediaserviceService,public router:Router) { 
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
  }
  OnImageLoad(event){
this.selectedFile=event.target.files;
this.selectedFile=this.selectedFile.item(0);
  }
  singlemedia(){
   
    console.log("SingleMedia method called");
    
    this.title = this.myFormGroup.controls['title'].value;
    this.description = this.myFormGroup.controls['description'].value;
    this.tags=this.myFormGroup.controls['tags'].value;
     this.date = new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.selectedFile.type == 'image/png') {
      this.file= `${this.title}${dateString}.png`;
    }
    if (this.selectedFile.type == 'image/jpeg' || this.selectedFile.type == 'image/jpg') {
      this.file = `${this.title}${dateString}.jpeg`;
    }
   console.log(this.file+"\n"+this.title+"\n"+this.description+"\n"+this.tags);
   let uploadfile=new MediaDetails(this.description,this.file,this.title,this.tags)
   this.mediaservice.pushFileToStorage(this.selectedFile,this.title,this.description,this.file,this.tags,this.selectedFile.type).subscribe(
    (response)=>{this.router.navigate(['/mymedia/'])});
   
  

   }
   message(){
     alert("you have uploaded the media files you have navigated to media")
   }


  ngOnInit() {
  }


    }
