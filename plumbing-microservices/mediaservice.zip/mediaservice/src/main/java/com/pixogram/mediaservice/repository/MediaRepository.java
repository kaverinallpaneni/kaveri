package com.pixogram.mediaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.mediaservice.entity.Media;

public interface MediaRepository extends JpaRepository<Media, Integer> {

}
