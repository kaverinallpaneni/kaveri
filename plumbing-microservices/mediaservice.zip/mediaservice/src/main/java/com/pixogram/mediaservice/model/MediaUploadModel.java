package com.pixogram.mediaservice.model;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MediaUploadModel implements Serializable{
	
	// private MultipartFile file;
	private Integer userId;
	private String title;
	private String description;
	private String tags;
	private String url;
	private String type;
	
	

}
