package com.pixogram.mediaservice.exception;

public class MediaNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MediaNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
