package com.pixogram.mediaservice.model;

import java.util.List;

import com.pixogram.mediaservice.entity.Media;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MediaModel {
	
	private List<Media> medialist;

}
