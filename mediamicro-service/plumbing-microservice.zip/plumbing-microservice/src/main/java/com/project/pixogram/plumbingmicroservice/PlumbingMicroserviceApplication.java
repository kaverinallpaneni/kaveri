package com.project.pixogram.plumbingmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlumbingMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlumbingMicroserviceApplication.class, args);
	}

}
