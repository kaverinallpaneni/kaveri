package com.project.pixogram.plumbingmicroservice.model;





import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MediaDataModel {
	private Integer userid;
	private String title;
	private String tags;
	private String type;
	private String description;
	//private MultipartFile file;
	private String url;
	
}
