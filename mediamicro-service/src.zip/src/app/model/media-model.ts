export class MediaDetails{
    userid:number;
    title:string;
    description:string;
    tags:string;
    url:string;
    type:string;

    constructor(title:string,description:string,tags:string,url:string,type:string){
this.title=title;
this.description=description;
this.tags=tags;
this.url=url;
this.type=type;


    }
}