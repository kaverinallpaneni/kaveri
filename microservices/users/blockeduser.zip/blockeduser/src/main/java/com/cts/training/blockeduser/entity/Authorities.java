package com.cts.training.blockeduser.entity;

public class Authorities {

}
