package com.cts.training.blockeduser.controller;

public class BlockedUserController {

}
