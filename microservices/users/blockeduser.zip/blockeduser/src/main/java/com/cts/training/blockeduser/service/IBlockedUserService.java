package com.cts.training.blockeduser.service;

import java.util.List;

import com.cts.training.blockeduser.entity.BlockedUser;



public interface IBlockedUserService {

	List<BlockedUser> findAllBlockedUser();
	BlockedUser findBlockedUserById(Integer id);
	boolean addBlockedUser(BlockedUser blockeduser);
	boolean updateBlockedUser(BlockedUser blockeduser);
	boolean deleteBlockedUser(Integer id);
}
