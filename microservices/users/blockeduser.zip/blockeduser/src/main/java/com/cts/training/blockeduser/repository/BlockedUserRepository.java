package com.cts.training.blockeduser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.blockeduser.entity.BlockedUser;


@Repository
public interface BlockedUserRepository extends JpaRepository<BlockedUser,Integer> {

}
