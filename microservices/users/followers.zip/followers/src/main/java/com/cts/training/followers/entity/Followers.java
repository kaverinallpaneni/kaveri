package com.cts.training.followers.entity;

public class Followers {

}
