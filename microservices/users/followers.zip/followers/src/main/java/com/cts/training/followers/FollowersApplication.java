package com.cts.training.followers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowersApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowersApplication.class, args);
	}

}
