package com.cts.training.comments.entity;

public class Comments {

}
