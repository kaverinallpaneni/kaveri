package com.cts.training.comments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
