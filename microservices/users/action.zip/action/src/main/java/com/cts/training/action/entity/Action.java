package com.cts.training.action.entity;

public class Action {

}
