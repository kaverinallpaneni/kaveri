package com.cts.training.action.service;

import java.util.List;

import com.cts.training.action.entity.Action;



public interface IActionService {
	

	List<Action> findAllActions();
	Action findActionById(Integer id);
	boolean addAction(Action action);
	boolean updateAction(Action action);
	boolean deleteAction(Integer id);

}
