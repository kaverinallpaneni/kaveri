package com.cts.training.action.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.action.entity.Action;

@Repository
public interface ActionRepository extends JpaRepository<Action,Integer>{

}
