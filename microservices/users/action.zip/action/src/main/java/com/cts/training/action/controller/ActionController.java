package com.cts.training.action.controller;

public class ActionController {

}
