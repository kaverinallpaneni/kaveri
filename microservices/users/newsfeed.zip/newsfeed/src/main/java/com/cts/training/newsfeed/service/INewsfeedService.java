package com.cts.training.newsfeed.service;

import java.util.List;

import com.cts.training.newsfeed.entity.Newsfeed;



public interface INewsfeedService {


	List<Newsfeed> findAllNewsfeeds();
	Newsfeed findNewsfeedById(Integer id);
	boolean addNewsfeed(Newsfeed newsfeed);
	boolean updateNewsfeed(Newsfeed newsfeed);
	boolean deleteNewsfeed(Integer id);
}
