package com.cts.training.newsfeed.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.newsfeed.entity.Newsfeed;

@Repository
public interface NewsfeedRepository extends JpaRepository<Newsfeed,Integer>{

}
