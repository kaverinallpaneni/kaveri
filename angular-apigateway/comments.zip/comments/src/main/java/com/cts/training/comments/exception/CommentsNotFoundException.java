package com.cts.training.comments.exception;

public class CommentsNotFoundException extends RuntimeException{


	public CommentsNotFoundException(String message) {
		
		super(message);
	}
}
