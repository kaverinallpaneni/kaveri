package com.cts.training.comments.service;

import java.util.List;

import com.cts.training.comments.entity.Comments;



public interface ICommentsService {


	List<Comments> findAllComments();
	Comments findCommentsById(Integer id);
	boolean addComments(Comments comments);
	boolean updateComments(Comments comments);
	boolean deleteComments(Integer id);
}
