package com.cts.training.user.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.user.entity.Authorities;
import com.cts.training.user.repository.AuthoritiesRepository;
;

public class AuthoritiesServiceImpl {

	@Autowired
	private AuthoritiesRepository  authoritiesRepository;
	
	public void saveauthority(Authorities role)
	{
		
		this.authoritiesRepository.save(role);
		
	}
}
