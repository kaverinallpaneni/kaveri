package com.cts.training.action.exception;

public class ActionNotFoundException extends RuntimeException {


	public ActionNotFoundException(String message) {
		
		super(message);
	}
}
