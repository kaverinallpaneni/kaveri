package com.cts.training.action.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.training.action.entity.Action;
import com.cts.training.action.exception.ActionErrorResponse;
import com.cts.training.action.exception.ActionNotFoundException;
import com.cts.training.action.service.IActionService;


@Controller
public class ActionController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IActionService actionService;
	
	// @RequestMapping(value =  "/products", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/actions") 
	public ResponseEntity<List<Action>> exposeAll() {
		
		List<Action> actions = this.actionService.findAllActions();
		// if(products.size() == 0)
		if(actions== null)
			throw new ActionNotFoundException("Not able to fetch records!!!");
		ResponseEntity<List<Action>> response = 
								new ResponseEntity<List<Action>>(actions, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/actions/{actionId}") // GET HTTP VERB
	public ResponseEntity<Action> getById(@PathVariable Integer actionId) {
		
		Action action= this.actionService.findActionById(actionId);
		if(action== null)
			throw new ActionNotFoundException("Action with id-" + actionId + " not Found");
		
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/products", method = RequestMethod.POST)
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<Action> save(@RequestBody Action action) {
		if(!this.actionService.addAction(action))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/users")
	public ResponseEntity<Action> saveUpdate(@RequestBody Action action) {
		if(!this.actionService.updateAction(action))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/actions/{actionId}")
	public ResponseEntity<Action> delete(@PathVariable Integer actionId) {
		
		Action action = this.actionService.findActionById(actionId);
		if(action== null)
			throw new ActionNotFoundException("Action with id-" + actionId + " not Found");
		
		// send productId to DAO via SERVICE
		this.actionService.deleteAction(actionId);
		
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	
	// for exception handling
	@ExceptionHandler  // ~catch
	public ResponseEntity<ActionErrorResponse> userNotFoundHandler(ActionNotFoundException ex) {
		// create error object
		ActionErrorResponse error = new ActionErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<ActionErrorResponse> response =
										new ResponseEntity<ActionErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<ActionErrorResponse> actionOperationErrorHAndler(Exception ex) {
		// create error object
		ActionErrorResponse error = new ActionErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<ActionErrorResponse> response =
										new ResponseEntity<ActionErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	

}
