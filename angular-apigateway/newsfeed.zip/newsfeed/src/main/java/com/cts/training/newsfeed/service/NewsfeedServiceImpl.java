package com.cts.training.newsfeed.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.newsfeed.entity.Newsfeed;
import com.cts.training.newsfeed.repository.NewsfeedRepository;


@Service
public class NewsfeedServiceImpl {

	@Autowired
	private NewsfeedRepository newsfeedRepository;
	
	public List<Newsfeed> findAllNewsfeed() {
		
		return this.newsfeedRepository.findAll();
	}
	
	public Newsfeed findNewsfeedById(Integer id) {
		// TODO Auto-generated method stub
		
		Optional<Newsfeed> record =  this.newsfeedRepository.findById(id);
		
		Newsfeed newsfeed = new Newsfeed();
		if(record.isPresent())
			newsfeed= record.get();
		return newsfeed;
		
	}


	public boolean addNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.save(newsfeed);
		return true;
	}


	public boolean updateNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.save(newsfeed);
		return true;
	}


	public boolean deleteNewsfeed(Integer id) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.deleteById(id);
		return true;
	}

}
