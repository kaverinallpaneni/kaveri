package com.cts.training.blockeduser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockeduserApplicationTests {

	@Test
	void contextLoads() {
	}

}
