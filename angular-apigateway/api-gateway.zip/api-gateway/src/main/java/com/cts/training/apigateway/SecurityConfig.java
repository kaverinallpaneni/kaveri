package com.cts.training.apigateway;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


public class SecurityConfig extends WebSecurityConfigurerAdapter{

	
	@Autowired
	private DataSource dataSource;
	
	// configure the credentials repository
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
			
		/********** JDBC Authentication ***************/
		
		// default schema
		auth.jdbcAuthentication().dataSource(dataSource);
		
		// custom schema
		/*auth.jdbcAuthentication().dataSource(dataSource)
			.usersByUsernameQuery("")  // for reading username and password (authentication)
			.authoritiesByUsernameQuery(""); // for reading roles (authorazation)
		*/
	}
	
	// secure the application : define the accessibility rule
	protected void configure(HttpSecurity http) throws Exception {
		http
			.cors() // auto configures application to use CrossOrigins
		.and()
			.csrf().disable() // form security will not conflict
			.authorizeRequests()
				.antMatchers(HttpMethod.OPTIONS, "/api/**").hasRole("USER")
				.antMatchers(HttpMethod.OPTIONS, "/login").hasRole("USER") // testing url for credentials
				// .antMatchers(HttpMethod.OPTIONS, "/login").hasAnyRole(new String[]{"USER","ADMIN","MANAGER"})
				// .antMatchers(HttpMethod.POST, "/api/**").hasRole("ADMIN")
				// .antMatchers(HttpMethod.GET, "/api/**").hasRole("USER")
			.and()
				.httpBasic();
	}
}
