package com.cts.training.followers.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.followers.entity.Followers;
import com.cts.training.followers.repository.FollowersRepository;


@Service
public class FollowersServiceImpl {
	
	@Autowired
	private FollowersRepository followersRepository;
	

	public List<Followers> findAllFollowers() {
		
		return this.followersRepository.findAll();
	}
	
	
	public Followers findFollowersById(Integer id) {
		// TODO Auto-generated method stub
		
		Optional<Followers> record =  this.followersRepository.findById(id);
		
		Followers followers = new Followers();
		if(record.isPresent())
			followers= record.get();
		return followers;
		
	}

	
	public boolean addFollowers(Followers followers) {
		// TODO Auto-generated method stub
		this.followersRepository.save(followers);
		return true;
	}


	public boolean updateFollowers(Followers followers) {
		// TODO Auto-generated method stub
		this.followersRepository.save(followers);
		return true;
	}

	
	public boolean deleteFollowers(Integer id) {
		// TODO Auto-generated method stub
		this.followersRepository.deleteById(id);
		return true;
	}


}
