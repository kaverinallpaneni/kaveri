package com.cts.training.followers.exception;

public class FollowersNotFoundException extends RuntimeException{
	

	public FollowersNotFoundException(String message) {
		
		super(message);
	}

}
