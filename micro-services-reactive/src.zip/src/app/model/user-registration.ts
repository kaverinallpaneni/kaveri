export class UserRegistrationDetails{
    id : number;
    firstname : string;
    lastname : string;
    username : string;
    email : string;
    password : string;
    dob:number;

    constructor(firstname,lastname,username,email,password,dob){
        this.firstname = firstname;
        this.lastname = lastname;
        this.username =  username;
        this.email = email;
        this.password = password;
        this.dob= dob;
    }
}