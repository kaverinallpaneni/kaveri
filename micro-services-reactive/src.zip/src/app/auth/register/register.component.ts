import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  /*styleUrls: ['./register.component.css']*/
})
export class RegisterComponent implements OnInit {
  [x: string]: any;


  username : string;
  password:string;
  email : string;
  repassword : string;
 
  myFormGroup : FormGroup;
 

  constructor(public router:Router,formBuilder: FormBuilder) { 
    this.myFormGroup=formBuilder.group({
     
      "username":new FormControl(""),
          "password": new FormControl(""),
          "repassword":new FormControl(""),
          "email":new FormControl("")
        
     });
  }
  checkLogin(txtLogin : HTMLInputElement, txtPass : HTMLInputElement,txtRepass:HTMLInputElement,txtEmail:HTMLInputElement){
    if(this.auth.authenticate(txtLogin.value,txtPass.value,txtRepass.value,txtEmail.value))
    {
     this.autherized=true;
     this.router.navigate(['/login']);
   }else{
     this.autherized=false;
 
   }
  }
  registerDetails(){
    this.username= this.myFormGroup.controls['username'].value;
      this.password=this.myFormGroup.controls['password'].value;
      this.repassword=this.myFormGroup.controls['repassword'].value;
      this.email=this.myFormGroup.controls['email'].value;
      
    
     }
    
  ngOnInit() {
  }

}
