import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
/*  styleUrls: ['./search.component.css']*/
})
export class SearchComponent implements OnInit {
  
  
search:string;
myFormGroup : FormGroup;
 
  constructor(formbuilder:FormBuilder) { 
    this.myFormGroup=formbuilder.group({
     
      "search":new FormControl(""),
         
        
     });
  }
  searchDetails(){
    this.search= this.myFormGroup.controls['search'].value;
  }
    ngOnInit() {
    }
  
  }

  