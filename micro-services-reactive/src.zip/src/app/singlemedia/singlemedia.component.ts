import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  /*styleUrls: ['./singlemedia.component.css']*/
})
export class SinglemediaComponent implements OnInit {
  title : string;
  description:string;
  tags : string;
  
 
  myFormGroup : FormGroup;
 
  constructor(formBuilder: FormBuilder) { 
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
          "description": new FormControl(""),
          "tags":new FormControl("")
        
     });
    

  }

  mediaDetails(){
    this.title= this.myFormGroup.controls['title'].value;
      this.description=this.myFormGroup.controls['description'].value;
      this.tags=this.myFormGroup.controls['tags'].value;
      
      
    
     }
  ngOnInit() {
  }

}
