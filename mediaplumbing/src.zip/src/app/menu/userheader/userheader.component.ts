import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-userheader',
  templateUrl: './userheader.component.html',
  //styleUrls: ['./userheader.component.css']
})
export class UserheaderComponent implements OnInit {

  profilePic : string;
  constructor(public auth:UserAuthService) { 
    this.profilePic = "http://localhost:8765/user-service/" + this.auth.getPic();
  }

  ngOnInit() {
  }

}
