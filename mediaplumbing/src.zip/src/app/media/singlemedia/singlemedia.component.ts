import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { MediaserviceService } from 'src/app/services/mediaservice.service';
import { Router } from '@angular/router';
import { MediaModel } from 'src/app/model/mediamodel';

@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  //styleUrls: ['./singlemedia.component.css']
})
export class SinglemediaComponent implements OnInit {
 /*description: String;
  myFormGroup: FormGroup;
  title: String;
  tags: String;

  constructor(formBuilder : FormBuilder) { 
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
  }
  singlemedia(){
    this.title= this.myFormGroup.controls['Title'].value;
    this.description=this.myFormGroup.controls['Description'].value;
    this.tags=this.myFormGroup.controls['Tags'].value;
    
}*/
title:string;
description: string;
tags: string;
type:string;
currentFileUpload:File;
myFormGroup:FormGroup;
  selectedFile: FileList;
  date: Date;
  file: string;
  url: string;
constructor(formBuilder: FormBuilder,public mediaService:MediaserviceService,public router:Router) {
  console.log("in form bilder of single media");
  this.myFormGroup=formBuilder.group({
    "title":new FormControl(""),
    "description":new FormControl(""),
    "tags":new FormControl("")
  });

}
OnImageLoad(event){
  this.selectedFile=event.target.files;
  this.currentFileUpload=this.selectedFile.item(0);
    }

singlemedia(){
  console.log("Single Media Details method");
  this.title= this.myFormGroup.controls['title'].value;
  this.description=this.myFormGroup.controls['description'].value;
  this.tags=this.myFormGroup.controls['tags'].value;
  this.date = new Date();
  let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
  if (this.currentFileUpload.type == 'image/png') {
    this.file = `${this.title}${dateString}.png`;
  }
  if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
    this.file = `${this.title}${dateString}.jpeg`;
  }
  console.log("Title : "+this.title+"\n"+"Description : "+this.description+"\n"+"Tags : "+this.tags);

  // let uploadfile=new MediaModel(this.description,this.file,this.title,this.tags,this.url)
  // console.log(uploadfile);
  this.mediaService.pushFileToStorage(this.currentFileUpload,this.title,this.description,this.file,this.tags,this.currentFileUpload.type).subscribe(
   (response)=>{this.router.navigate(['/mymedia/'])});
  
 

  }
  message(){
    alert("you have uploaded the media files you have navigated to mediadetails")
  }




  ngOnInit() {
  }

}
