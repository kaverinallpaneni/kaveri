import { MediaModel } from './mediamodel';

export class MediaListModel {

	fileList : Array<MediaModel>;
}