export class MediaModel{
  

  title:string;
  description:string;
  tags:string;
  type:string;
  
  userId:number;
  


  

  constructor(title:string,description:string,tags:string,type:string,userId:number){
             this.title=title;
             this.description=description;
             this.tags=tags;
             this.type=type;
             this.userId=userId;
           
    }
}