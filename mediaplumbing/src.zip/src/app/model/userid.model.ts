export class Userid{
    
	  id:number;
	  firstname:string;
      lastname:string;
      profilePic:string;
       
      constructor(firstname:string,lastname:string,profilePic:string)
      {
          this.firstname=firstname;
          this.lastname=lastname;
          this.profilePic=profilePic;
      }
}