package com.cts.training.user.exception;

public class UserNotFoundException extends RuntimeException{

	public UserNotFoundException(String message) {
		
		super(message);
	}
}
