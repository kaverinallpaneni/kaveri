package com.cts.training.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.user.entity.Authorities;

public interface AuthoritiesRepository extends JpaRepository<Authorities,Integer>{

	
}
