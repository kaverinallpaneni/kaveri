package com.cts.training.followers.service;

import java.util.List;

import com.cts.training.followers.entity.Followers;



public interface IFollowersService {


	List<Followers> findAllFollowers();
	Followers findFollowersById(Integer id);
	boolean addFollowers(Followers followers);
	boolean updateFollowers(Followers followers);
	boolean deleteFollowers(Integer id);
}
