package com.cts.training.followers.controller;

public class FollowersController {

}
