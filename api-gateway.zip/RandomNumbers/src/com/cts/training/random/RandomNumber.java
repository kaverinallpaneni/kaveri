package com.cts.training.random;

import java.util.Random;

public class RandomNumber {
	public static void main(String[]args) {
		
		  Random rand = new Random();
	
	        int rand_int1 = rand.nextInt(25); 
	        int rand_int2 = rand.nextInt(25); 
	  
	        System.out.println("Random Integers: "+rand_int1); 
	        System.out.println("Random Integers: "+rand_int2); 
	  
	        
	}
	
	
}
