package com.cts.training.media.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "media")
public class Media {
@Id 
	
	private Integer id;
	@Column
	private Integer userid;
	@Column
	private String title;
	
	@Column
	private String description;
	
	@Column
	private String mimetype;
	
	@Column
	private Integer size;
	
	@Column
	private String posterfileurl;
	
	@Column
	private String fileurl;
	
	
	@Column
	private Boolean hide ;
	
	@CreationTimestamp
	@Column
	private LocalDateTime createdon ;
	
	@UpdateTimestamp
	@Column
	private LocalDateTime updatedon ;
	
	@Column
	private String tags ;
	
	
}
