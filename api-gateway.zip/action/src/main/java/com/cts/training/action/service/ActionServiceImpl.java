package com.cts.training.action.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.action.entity.Action;
import com.cts.training.action.repository.ActionRepository;

@Service
public class ActionServiceImpl {

	@Autowired
	private ActionRepository actionRepository;
	
	
	public List<Action> findAllActions() {
		
		return this.actionRepository.findAll();
	}
	
	public Action findActionById(Integer id) {
		// TODO Auto-generated method stub
		
		Optional<Action> record =  this.actionRepository.findById(id);
		
		Action action = new Action();
		if(record.isPresent())
			action = record.get();
		return action;
		
	}

	
	public boolean addAction(Action action) {
		// TODO Auto-generated method stub
		this.actionRepository.save(action);
		return true;
	}

	
	public boolean updateAction(Action action) {
		// TODO Auto-generated method stub
		this.actionRepository.save(action);
		return true;
	}

	
	public boolean deleteAction(Integer id) {
		// TODO Auto-generated method stub
		this.actionRepository.deleteById(id);
		return true;
	}

}
