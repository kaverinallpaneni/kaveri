package com.cts.training.action.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "actions")
public class Action {

@Id // primary key
	
	private Integer id;
	@Column
	private Integer mediaid;
	
	@Column
	private Integer userid;
	
	@Column
	private Boolean status;
	
	@CreationTimestamp
	@Column
	private LocalDateTime createdon ;
}
