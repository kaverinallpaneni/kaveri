package com.cts.training.blockeduser.exception;

public class BlockedUserNotFoundException extends RuntimeException{


	public BlockedUserNotFoundException(String message) {
		
		super(message);
	}
}
