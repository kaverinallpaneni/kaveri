package com.cts.training.blockeduser.entity;

public class BlockedUser {

}
