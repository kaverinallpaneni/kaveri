package com.cts.training.blockeduser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockeduserApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockeduserApplication.class, args);
	}

}
