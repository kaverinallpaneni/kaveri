package com.cts.training.blockeduser.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.blockeduser.entity.BlockedUser;
import com.cts.training.blockeduser.repository.BlockedUserRepository;


@Service
public class BlockedUserImpl {

	@Autowired
	private BlockedUserRepository blockeduserRepository;
	

	public List<BlockedUser> findAllBlockedUsers() {
		
		return this.blockeduserRepository.findAll();
	}
	

	public BlockedUser findBlockedUserById(Integer id) {
		// TODO Auto-generated method stub
		
		Optional<BlockedUser> record =  this.blockeduserRepository.findById(id);
		
		BlockedUser blockeduser = new BlockedUser();
		if(record.isPresent())
			blockeduser = record.get();
		return blockeduser;
		
	}


	public boolean addBlockedUser(BlockedUser blockeduser) {
		// TODO Auto-generated method stub
		this.blockeduserRepository.save(blockeduser);
		return true;
	}

	
	public boolean updateBlockedUser(BlockedUser blockeduser) {
		// TODO Auto-generated method stub
		this.blockeduserRepository.save(blockeduser);
		return true;
	}


	public boolean deleteBlockedUser(Integer id) {
		// TODO Auto-generated method stub
		this.blockeduserRepository.deleteById(id);
		return true;
	}

}
