package com.cts.training.newsfeed.controller;

public class NewsfeedController {

}
