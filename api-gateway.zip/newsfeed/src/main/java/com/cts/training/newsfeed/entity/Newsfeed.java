package com.cts.training.newsfeed.entity;

public class Newsfeed {

}
