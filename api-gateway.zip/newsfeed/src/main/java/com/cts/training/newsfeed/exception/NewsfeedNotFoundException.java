package com.cts.training.newsfeed.exception;

public class NewsfeedNotFoundException extends RuntimeException{
	

	public NewsfeedNotFoundException(String message) {
		
		super(message);
	}

}
