package com.cts.training.comments.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.comments.entity.Comments;


@Repository
public interface CommentsRepository extends JpaRepository<Comments,Integer> {

}
