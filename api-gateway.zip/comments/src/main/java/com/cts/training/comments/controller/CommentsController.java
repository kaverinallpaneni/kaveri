package com.cts.training.comments.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.training.comments.entity.Comments;
import com.cts.training.comments.exception.CommentsErrorResponse;
import com.cts.training.comments.exception.CommentsNotFoundException;
import com.cts.training.comments.service.ICommentsService;


@Controller
public class CommentsController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ICommentsService commentsService;
	
	// @RequestMapping(value =  "/products", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("comments") 
	public ResponseEntity<List<Comments>> exposeAll() {
		
		List<Comments> comments = this.commentsService.findAllComments();
		// if(products.size() == 0)
		if(comments== null)
			throw new CommentsNotFoundException("Not able to fetch records!!!");
		ResponseEntity<List<Comments>> response = 
								new ResponseEntity<List<Comments>>(comments, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/comments/{commentsId}") // GET HTTP VERB
	public ResponseEntity<Comments> getById(@PathVariable Integer commentsId) {
		
		Comments comments = this.commentsService.findCommentsById(commentsId);
		if(comments== null)
			throw new CommentsNotFoundException("Comments with id-" + commentsId + " not Found");
		
		ResponseEntity<Comments> response = 
				new ResponseEntity<Comments>(comments, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/products", method = RequestMethod.POST)
	@PostMapping("/comments") // POST HTTP VERB
	public ResponseEntity<Comments> save(@RequestBody Comments comments) {
		if(!this.commentsService.addComments(comments))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<Comments> response = 
				new ResponseEntity<Comments>(comments, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/comments")
	public ResponseEntity<Comments> saveUpdate(@RequestBody Comments comments) {
		if(!this.commentsService.updateComments(comments))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<Comments> response = 
				new ResponseEntity<Comments>(comments, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/comments/{commentsId}")
	public ResponseEntity<Comments> delete(@PathVariable Integer commentsId) {
		
		Comments comments = this.commentsService.findCommentsById(commentsId);
		if(comments== null)
			throw new CommentsNotFoundException("Comments with id-" + commentsId + " not Found");
		
		// send productId to DAO via SERVICE
		this.commentsService.deleteComments(commentsId);
		
		ResponseEntity<Comments> response = 
				new ResponseEntity<Comments>(comments, HttpStatus.OK);

		return response;
	}
	
	
	// for exception handling
	@ExceptionHandler  // ~catch
	public ResponseEntity<CommentsErrorResponse> commentsNotFoundHandler(CommentsNotFoundException ex) {
		// create error object
		CommentsErrorResponse error = new CommentsErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<CommentsErrorResponse> response =
										new ResponseEntity<CommentsErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<CommentsErrorResponse> commentsOperationErrorHAndler(Exception ex) {
		// create error object
		CommentsErrorResponse error = new CommentsErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<CommentsErrorResponse> response =
										new ResponseEntity<CommentsErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	

}
