package com.cts.training.comments.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.comments.entity.Comments;
import com.cts.training.comments.repository.CommentsRepository;


@Service
public class CommentsServiceImpl {

	@Autowired
	private CommentsRepository commentsRepository;
	
	
	public List<Comments> findAllComments() {
		
		return this.commentsRepository.findAll();
	}
	
	
	public Comments findCommentsById(Integer id) {
		// TODO Auto-generated method stub
		
		Optional<Comments> record =  this.commentsRepository.findById(id);
		
		Comments comments = new Comments();
		if(record.isPresent())
			comments = record.get();
		return comments;
		
	}


	public boolean addComments(Comments comments) {
		// TODO Auto-generated method stub
		this.commentsRepository.save(comments);
		return true;
	}


	public boolean updateComments(Comments comments) {
		// TODO Auto-generated method stub
		this.commentsRepository.save(comments);
		return true;
	}

	
	public boolean deleteComments(Integer id) {
		// TODO Auto-generated method stub
		this.commentsRepository.deleteById(id);
		return true;
	}

}
